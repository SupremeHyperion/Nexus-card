import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes"; // Assicurati che il file si chiami routes.ts
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// 🛡️ CREAZIONE TABELLE (Senza questo il build fallisce perché non trova 'users')
(async () => {
  try {
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        xp INTEGER DEFAULT 0,
        level INTEGER DEFAULT 1,
        joined_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log("Database sincronizzato con successo");
  } catch (e) {
    console.error("Errore inizializzazione database:", e);
  }
})();

// Logging delle richieste
app.use((req, res, next) => {
  const start = Date.now();
  res.on("finish", () => {
    const duration = Date.now() - start;
    console.log(`${req.method} ${req.path} ${res.statusCode} in ${duration}ms`);
  });
  next();
});

// Registrazione Rotte
const server = registerRoutes(app);

// Gestione Errori globale
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  res.status(status).json({ message });
});

// Porta per il deployment
const PORT = 5000;
server.listen(PORT, "0.0.0.0", () => {
  console.log(`Server attivo sulla porta ${PORT}`);
});
