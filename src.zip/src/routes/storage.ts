import { type Card, type InsertCard } from "@shared/schema";

export interface IStorage {
  getCards(): Promise<Card[]>;
  getCard(id: number): Promise<Card | undefined>;
}

export class MemStorage implements IStorage {
  private cards: Map<number, Card>;
  idCounter: number;

  constructor() {
    this.cards = new Map();
    this.idCounter = 1;
    this.initDefaultCards();
  }

  async getCards(): Promise<Card[]> {
    return Array.from(this.cards.values());
  }

  async getCard(id: number): Promise<Card | undefined> {
    return this.cards.get(id);
  }

  private initDefaultCards() {
    const defaultCards: Card[] = [
      { id: 1, name: "Nexus Core", rarity: "Legendary", hp: 200, atk: 150, image: "" },
      { id: 2, name: "Data Stream", rarity: "Common", hp: 80, atk: 40, image: "" }
    ];
    defaultCards.forEach(c => this.cards.set(c.id, c));
  }
}

export const storage = new MemStorage();
